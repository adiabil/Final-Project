import mongoose from 'mongoose';
const doctorsSchema = new mongoose.Schema({
    name:{
        type: String,
        required:true,
    }, 
    email:{
        type: String,
        required:true,
        unique: true,
    }, 
    image:{
        type:String,
        default: null,
    },
    isAdmin:{
        type: Boolean,
        default: false,
    }
   
   
    
}, {timestamps: true})

export default mongoose.model('doctors', doctorsSchema)