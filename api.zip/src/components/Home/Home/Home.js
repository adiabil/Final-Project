import React from "react";
import Footer from "../../Shared/Footer/Footer";
import Header from "../Header/Header";

const Home = () => {
  return (
    <div>
      <Header current={"home"}></Header>
      {/* <Services></Services>
            <FeaturedService></FeaturedService>
            <Appointment></Appointment>
            <Testimonial></Testimonial>
            <Blog></Blog>
            <Doctor></Doctor>
            <Contact></Contact>
            <Footer></Footer> */}
    </div>
  );
};

export default Home;
