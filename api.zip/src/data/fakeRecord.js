export const fakeRecord = [
  {
    id: 1,
    avatar: '/vite.svg',
    name: 'John Doe',
    text: 'Hi there! How are you? Hi there! How are you? Hi there! How are you? Hi there! How are you?',
    time: '09:00',
    unread: 5
  },
  {
    id: 2,
    avatar: '/vite.svg',
    name: 'Jessic Woo',
    text: 'Hi there',
    time: '08:00',
    unread: 0
  },
  {
    id: 3,
    avatar: '/vite.svg',
    name: 'Kelly Clarkson',
    text: "What doesn't kill you make you stronger",
    time: '07:30',
    unread: 2
  },
  {
    id: 4,
    avatar: '/vite.svg',
    name: 'John Doe',
    text: 'Hi there! How are you? Hi there! How are you? Hi there! How are you? Hi there! How are you?',
    time: '09:00',
    unread: 5
  },
  {
    id: 5,
    avatar: '/vite.svg',
    name: 'Jessic Woo',
    text: 'Hi there',
    time: '08:00',
    unread: 0
  },
  {
    id: 6,
    avatar: '/vite.svg',
    name: 'Kelly Clarkson',
    text: "What doesn't kill you make you stronger",
    time: '07:30',
    unread: 2
  },
  {
    id: 7,
    avatar: '/vite.svg',
    name: 'Jessic Woo',
    text: 'Hi there',
    time: '08:00',
    unread: 0
  },
  {
    id: 8,
    avatar: '/vite.svg',
    name: 'Kelly Clarkson',
    text: "What doesn't kill you make you stronger",
    time: '07:30',
    unread: 2
  }
];
